
<!DOCTYPE html>
<html lang="en">
  <head>
    @include('head')
  </head>
  <body>

    @include('header')

     @yield('container')

      @include('footer')
  </body>
</html>
