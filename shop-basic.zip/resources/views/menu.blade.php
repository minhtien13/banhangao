<ul class="header-menu__list">
    <li class="header-menu__item">
        <a href="/" class="header-menu__link">Trang chủ</a>
    </li>
    <li class="header-menu__item">
        <a href="/san-pham.html" class="header-menu__link">Sản phẩm</a>
    </li>
    <li class="header-menu__item">
        <a href="/gioi-thieu.html" class="header-menu__link">Giới thiệu</a>
    </li>
    <li class="header-menu__item">
        <a href="/tin-tuc.html" class="header-menu__link">Tin tức</a>
    </li>
    <li class="header-menu__item">
        <a href="/lien-he.html" class="header-menu__link">Liên hệ</a>
    </li>
</ul>