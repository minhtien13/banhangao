

<?php $__env->startSection('container'); ?>
<form  action="" method="POST">
    <div class="card-body">
      <div class="form-group">
        <label for="exampleInputEmail1">Têm menu</label>
        <input type="text" name="name" value="<?php echo e($data['name']); ?>" class="form-control" id="exampleInputEmail1" placeholder="Tên menu">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Danh mực</label>
        <select name="parent_id" id="" class="form-control">
          <option value="0"> __danh mực cha__ </option>
          
          <?php $__currentLoopData = $dataMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($row->id); ?>" <?php echo e($row->id == $data->menu_id ? 'selected' : ''); ?>> <?php echo e($row->name); ?> </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Phân loại</label>
        <select name="limited_edition" id="" class="form-control">
          <option value="0" <?php echo e($data->limited_edition == 0 ? 'selected' : ''); ?>>thường</option>
          <option value="1" <?php echo e($data->limited_edition == 1 ? 'selected' : ''); ?>>phiên bản đật biệt</option>
        </select>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">trại thái</label>
        <select name="is_active" id="" class="form-control">
          <option value="1" <?php echo e($data['is_active'] == 1 ? 'selected' : ''); ?>>Công khai</option>
          <option value="0" <?php echo e($data['is_active'] == 0 ? 'selected' : ''); ?>>không Công khai</option>
        </select>
      </div>
    </div>
    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Cập nhật menu</button>
    </div>
    <?php echo csrf_field(); ?>
  </form>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/menus/edit.blade.php ENDPATH**/ ?>