

<?php $__env->startSection('container'); ?>
    



<section class="product">
    <div class="container">
        
        <div class="product__bar product__bar--space-between product__bar--flex">
            <h2 class="product__bar-heading">Kết quả Tìm kiểm</h2>
        </div>

        <?php if(count($product) == 0): ?>
            <h3 class="search__message">Không có sản phẩm nào hết </h3>
        <?php endif; ?>

      <ul class="product-list">
        
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
        <li class="product-list__item">
          <div class="product-list__ima">
            <img
              src="<?php echo e($productItem->thumb); ?>"
              alt="SHOPBASIC io vn"
              class="product-list__image"
            />
            <img
              src="/template/images/logo.jpg"
              alt=""
              class="product-list__logo"
            />

            <div class="product-list__active">
              <a href="/san-pham/<?php echo e($productItem->slug_url); ?>.html" class="product-list__active-link">
                <i class="fas fa-water"></i>
              </a>
              <a
                href="javascript:void(0)"
                onclick="loadDetall(<?php echo e($productItem->id); ?>)"
                class="product-list__active-link"
              >
                <i class="fas fa-eye"></i>
              </a>
            </div>
          </div>
          <div class="product-list__content">
            <a href="/san-pham/<?php echo e($productItem->slug_url); ?>.html" class="product-list__title">
              <h1><?php echo e($productItem->title); ?></h1>
            </a>
            
            <?php echo App\helpers\helper::headPrice($productItem->price, $productItem->price_sale); ?>


            <span
              class="product-list__color"
              style="--product-color: <?php echo e($productItem->product_color); ?>"
            ></span>
          </div>
        </li>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
    </div>
</section>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/porducts/search.blade.php ENDPATH**/ ?>