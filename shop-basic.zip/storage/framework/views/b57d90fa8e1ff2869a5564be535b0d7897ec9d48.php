

<?php $__env->startSection('container'); ?>
    ldpeoweolr rr
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/home/main.blade.php ENDPATH**/ ?>