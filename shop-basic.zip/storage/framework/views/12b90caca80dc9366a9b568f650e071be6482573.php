
<?php $__env->startSection('container'); ?>   

    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('bread', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="user__main">
       <div class="container user__main__container">
          
            <?php echo $__env->make('account.sildebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="user__main__home">
                <h3 class="user__main__home__heading">đổi mật khẩu tài khoản</h3>
                <p class="user__main__home__txt">
                    Để đảm bảo mật khẩu bảo mật khi đổi phải từ 6 ký tự 
                </p>

                <div class="user__main__home__pass">
                    <div class="user__main__home__pass-war">
                        <form action="/user/acc/change" method="POST" class="account__main__form">
                            <div class="account__main__form-war">
                                <label for="" class="account__main__form-label  
                                        <?php if($errors->get('password')): ?> danger <?php endif; ?>">Mật khẩu cũ <span class="danger">*</span>
                                </label>

                                <input type="password" name="password" class="account__main__form-input" placeholder="Mật khẩu">
                
                                <?php if($errors->get('password')): ?>
                                    <p class="account__main__form-error"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="account__main__form-war">
                                <label for="" class="account__main__form-label 
                                        <?php if($errors->get('password_new')): ?> danger <?php endif; ?>">Mật khẩu mới <span class="danger">*</span>
                                </label>

                                <input type="password" name="password_new" class="account__main__form-input" placeholder="Mật khẩu mới">
                
                                <?php if($errors->get('password_new')): ?>
                                    <p class="account__main__form-error"><?php echo e($errors->first('password_new')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="account__main__form-war">
                                <label for="" class="account__main__form-label
                                    <?php if($errors->get('password_confirmed')): ?> danger <?php endif; ?> ">Xác mật khẩu mới <span class="danger">*</span>
                                </label>
                                <input type="password" name="password_confirmed" class="account__main__form-input" placeholder="Xác mật khẩu mới">
                            
                                <?php if($errors->get('password_confirmed')): ?>
                                     <p class="account__main__form-error"><?php echo e($errors->first('password_confirmed')); ?></p>
                                <?php endif; ?>
                            </div>

                            <?php echo csrf_field(); ?>

                            <div class="account__main__form-war">
                            <button class="user__main__home__pass-btn account__main__form-btn btn">Đổi mật khẩu mới</button>
                            </div>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/account/password.blade.php ENDPATH**/ ?>