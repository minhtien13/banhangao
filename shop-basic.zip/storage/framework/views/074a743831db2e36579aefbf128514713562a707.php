

<?php $__env->startSection('container'); ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>TÊN MENU</th>
                <th>TRẠI THÁI</th>
                <th>CẬP NHẬT</th>
                <th>&nbsp;</th>
            </tr>
        </thead>

        <tbody>
           <?php echo App\helpers\helper::menus($data); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/menus/list.blade.php ENDPATH**/ ?>