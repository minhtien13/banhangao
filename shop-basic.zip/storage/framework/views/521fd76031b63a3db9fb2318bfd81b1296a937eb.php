

<?php $__env->startSection('container'); ?>
<form  action="" method="POST">
    <div class="card-body">
      <div class="form-group">
        <label for="exampleInputEmail1">Têm menu</label>
        <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Tên menu">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Danh mực</label>
        <select name="parent_id" id="" class="form-control">
          <option value="0"> __danh mực cha__ </option>
          
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($row->id); ?>"> <?php echo e($row->name); ?> </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Phân loại</label>
        <select name="limited_edition" id="" class="form-control">
          <option value="0">thường</option>
          <option value="1">phiên bản đật biệt</option>
        </select>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">trại thái</label>
        <select name="is_active" id="" class="form-control">
          <option value="1">Công khai</option>
          <option value="0">không Công khai</option>
        </select>
      </div>
    </div>
    <div class="card-footer d-flex">
      <button type="submit" class="btn btn-primary">Thêm menu</button>
      <button type="reset" class="btn btn-secondary ml-auto">Chanel</button>
    </div>
    <?php echo csrf_field(); ?>
  </form>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/menus/add.blade.php ENDPATH**/ ?>