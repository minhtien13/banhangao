

<?php $__env->startSection('container'); ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>TÊN TÀI KHOẢN</th>
                <th>VAI TRÒ</th>
                <th>TRẠI THÁI</th>
                <th>CẬP NHẬT</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($row->level == 3): ?>
                    <tr>
                        <td style="width: 20px;"><?php echo e($row->id); ?></td>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->level == 3 ? 'Khách hàng' : 'Admin'); ?></td>
                        <td><?php echo $row->staturs == 1 ? '<p class="text-primary">Hoạt động</p>' : '<p class="text-danger">Tạm khóa</p>'; ?></td>
                        <td><?php echo e($row->updated_at); ?></td>
                        <td>
                            <div class="main__table__delete">
                                <a href="javascript:void(0)" onClick="deleteRow('/admin/account/remove', <?php echo e($row->id); ?> )" class="main__table__delete__link main__table__delete__link--remove">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <a href="/admin/account/edit/<?php echo e($row->id); ?>" class="main__table__delete__link main__table__delete__link--edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        </td>
                    </tr>    
                <?php endif; ?>
             
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    
    </table>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/accounts/contomer.blade.php ENDPATH**/ ?>