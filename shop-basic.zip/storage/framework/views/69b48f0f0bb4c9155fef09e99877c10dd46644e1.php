

<?php $__env->startSection('container'); ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>TÊN SẢN PHẨM</th>
                <th>MENU</th>
                <th>GIÁ GỐC</th>
                <th>GIÁ GIÁM</th>
                <th>HÌNH</th>
                <th>TRẠI THÁI</th>
                <th>CẬP NHẬT</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="width: 20px;"><?php echo e($row->id); ?></td>
                    <td><?php echo e($row->title); ?></td>
                    <td>  
                        <?php if(isset( $row->menu->id)): ?>
                           <?php echo e($row->menu->name); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(number_format($row->price)); ?></td>
                    <td><?php echo e(number_format($row->price_sale)); ?></td>
                    <td>
                        <img src="<?php echo e($row->thumb); ?>" alt="" class="main__product__image">
                    </td>
                    <td><?php echo \App\helpers\helper::staturs($row->is_active); ?></td>
                    <td><?php echo e($row->updated_at); ?></td>
                    <td>
                        <div class="main__table__delete">
                            <a href="javascript:void(0)" onClick="deleteRow('/admin/product/remove', <?php echo e($row->id); ?> )" class="main__table__delete__link main__table__delete__link--remove">
                                <i class="fas fa-trash"></i>
                            </a>
                            <a href="/admin/product/edit/<?php echo e($row->id); ?>" class="main__table__delete__link main__table__delete__link--edit">
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>
                    </td>
                </tr>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    
    </table>
      <div class="">
          <?php echo e($data->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/products/list.blade.php ENDPATH**/ ?>