<div class="bread">
    <div class="container">
      <ul class="bread__list">
        <li class="bread__list-item">
          <a href="/" class="bread__list-link--home bread__list-link">Trang chủ /</a>
        </li>

        <?php if($staturs == 3): ?>
          <?php echo App\helpers\helper::bar($detall->menu_id, $detall->title); ?>

        <?php endif; ?>

        <?php if($staturs != 3): ?>
          <?php echo App\helpers\helper::bar(0, $title); ?>

        <?php endif; ?>
        
      </ul>
    </div>
  </div><?php /**PATH E:\laragon\www\shop-basic\resources\views/bread.blade.php ENDPATH**/ ?>