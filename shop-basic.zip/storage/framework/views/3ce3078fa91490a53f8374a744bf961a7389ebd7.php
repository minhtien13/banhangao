<?php if(\Session::get('success')): ?>
<div class="message__main message__main--success"><?php echo e(\Session::get('success')); ?></div>    
<?php endif; ?>

<?php if(\Session::get('error')): ?>
<div class="message__main message__main--error"><?php echo e(\Session::get('error')); ?></div>    
<?php endif; ?>
<?php /**PATH E:\laragon\www\shop-basic\resources\views/alert.blade.php ENDPATH**/ ?>