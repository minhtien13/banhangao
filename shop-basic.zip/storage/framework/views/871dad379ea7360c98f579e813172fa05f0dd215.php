

<?php $__env->startSection('container'); ?>
<div class="checkout">
    <section class="container">
      <div class="checkout__main">
        <h2 class="checkout__main-heading">thông tin của bạn!</h2>
        <form method="post" action="/cart/store" class="checkout__main__form">
          <div class="checkout__main__form__row">
            <label for="" class="checkout__main__form-label"
              >Tên người nhận</label
            >
            <input type="text" name="name" class="checkout__main__form-input" />
          </div>
          <div class="checkout__main__form__row">
            <label for="" class="checkout__main__form-label"
              >Số điện thoại</label
            >
            <input type="text" name="phone" class="checkout__main__form-input" />
          </div>
          <div class="checkout__main__form__row">
            <label for="" class="checkout__main__form-label">gmail</label>
            <input type="text" name="email" class="checkout__main__form-input" />
          </div>
          <div class="checkout__main__form__row">
            <label for="" class="checkout__main__form-label">Dịa chỉ</label>
            <input type="text" name="address" class="checkout__main__form-input" />
          </div>
          <div class="checkout__main__form__row">
            <button type="submit" class="btn checkout__main__form-btn">DẶT HÀNG</button>
          </div>

          <?php echo csrf_field(); ?>
        </form>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/carts/checkout.blade.php ENDPATH**/ ?>