
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('bread', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="user__main">
       <div class="container user__main__container">
          
            <?php echo $__env->make('account.sildebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="user__main__home">
                <h3 class="user__main__home__heading">thông tin tài khoản</h3>

                <div class="user__main__home__info">
                    <div class="user__main__home__info-war">
                        <div class="user__main__home__info__ima">
                            <img src="/template/images/avatar.jpg" alt="" class="user__main__home__info__avatar">
                        </div>
                    </div>

                    <div class="user__main__home__info-war">
                        <span class="user__main__home__item">
                            <b>Họ, tên:</b>
                            <?php echo e($account->name); ?>

                        </span>
    
                        <span class="user__main__home__item">
                            <b>Gmail:</b>
                            <?php echo e($account->email); ?>

                        </span> 
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/account/acc.blade.php ENDPATH**/ ?>