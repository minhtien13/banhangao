

<?php $__env->startSection('container'); ?>
    <?php echo $__env->make('bread', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="introduce">
        <div class="container">
          <div class="introduce__container">
            <h2
              class="introduce__container__heading contact__container__heading"
            >
             <?php echo e($intro->title); ?>

            </h2>
            <div class="introduce__container__content">
              <?php echo $intro->content; ?>

            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/blogs/intro.blade.php ENDPATH**/ ?>