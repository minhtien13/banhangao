

<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('bread', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="account">
        <div class="container">
          <div class="account__top">
            <h3 class="account__top__heading">ĐĂNG KÝ TÀI KHOẢN</h3>
            <span class="account__top__txt">
              Bạn dã có tài khoảng ? đăng nhập 
              <a href="/dang-nhap.html" class="account__top__txt-link">
                 tại đây
              </a>
            </span>
          </div>

          <div class="account__main">
            <p class="account__main__label">thông tin cá nhân</p>
            <form action="/user/acc/register" method="POST" class="account__main__form">
              <div class="account__main__form-war">
                <label for="" class="account__main__form-label">Họ tên <span class="danger">*</span> </label>
                <input type="text" name="name" class="account__main__form-input" placeholder="Họ tên">

                <?php if($errors->get('name')): ?>
                    <p class="account__main__form-error"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
              </div>

              <div class="account__main__form-war">
                <label for="" class="account__main__form-label">Gmail <span class="danger">*</span> </label>
                <input type="email" name="email" class="account__main__form-input" placeholder="Gmail">

                <?php if($errors->get('email')): ?>
                    <p class="account__main__form-error"><?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
              </div>

              <div class="account__main__form-war">
                <label for="" class="account__main__form-label">Mật khẩu <span class="danger">*</span></label>
                <input type="password" name="password" class="account__main__form-input" placeholder="Mật khẩu">

                <?php if($errors->get('password')): ?>
                    <p class="account__main__form-error"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
              </div>

              <?php echo csrf_field(); ?>
              <div class="account__main__form-war">
                <button class="account__main__form-btn btn">Đăng ký</button>
              </div>
            </form>

            <div class="account__main__connect">
              <p class="account__main__connect__txt">Hoăc đăng nhập bằng</p>
              <div class="account__main__connect__war">
                <a href="" class="account__main__connect__war-link">
                  <p class="account__main__connect__war-icon">
                    <i class="fab fa-facebook-f"></i>
                  </p>
                  <span class="account__main__connect__war-text">facebook</span>
                </a>
                <a href="" class="account__main__connect__war-link">
                  <p class="account__main__connect__war-icon">
                    <i class="fab fa-google-plus-g"></i>
                  </p>
                  <span class="account__main__connect__war-text">Google</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/account/register.blade.php ENDPATH**/ ?>