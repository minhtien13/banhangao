

<?php $__env->startSection('container'); ?>
    <div class="blog">
        <section class="container">
            <h2 class="blog__heading"><?php echo e($data->title); ?></h2>

            <div class="blog_content">
                <?php echo $data->content; ?>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/blogs/cage.blade.php ENDPATH**/ ?>