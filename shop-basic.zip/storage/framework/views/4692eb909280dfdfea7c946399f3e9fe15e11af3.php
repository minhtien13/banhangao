

<?php $__env->startSection('container'); ?>
    <div class="mt-3  mb-3">
        <ul>
            <li><b>TÊM KHÁCH HÀNG: </b><?php echo e($curtomer->name); ?></li>
            <li><b>SỐ ĐIỆN THOẠI: </b><?php echo e($curtomer->phone); ?></li>
            <li><b>ĐỊA CHỈ: </b><?php echo e($curtomer->address); ?></li>
            <li><b>GMAIL: </b><?php echo e($curtomer->email); ?></li>
        </ul>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>TÊN SP</th>
                <th>GIÁ</th>
                <th>SỐ LƯỢNG SP</th>
                <th>TỔNG TIỀN</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $priceAll = 0;
            ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <?php
                    $price = $row->product->price_sale != 0 ? $row->product->price_sale : $row->product->price;
                    $priceAll += $price;
                ?> 

                <tr>
                    <td><?php echo e($row->product->title); ?></td>
                    <td><?php echo e(number_format($price)); ?></td>
                    <td><?php echo e($row->qty); ?></td>
                    <td><?php echo e(number_format($row->price)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
         
    </table>

    <div class="card-footer d-flex mt-2">
      <b>tồng tiền:</b>
      <p class="ml-auto text-danger">
        <?php echo e(number_format($priceAll)); ?><sup>đ</sup>
      </p>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/admin/carts/order.blade.php ENDPATH**/ ?>