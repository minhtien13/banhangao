
<?php $__env->startSection('container'); ?>
    <?php echo $__env->make('bread', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="user__main">
        <div class="container user__main__container">
            <?php echo $__env->make('account.sildebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="user__main__home">
                <h3 class="user__main__home__heading">đơn hàng của bạn</h3>

                <div class="user__main__home__order">
                    <table>
                        <thead>
                            <tr>
                                <th>Đơn hàng</th>
                                <th>Ngày</th>
                                <th>Giá trị đơn hàng</th>
                                <th>Dịa chỉ</th>
                                <th>TT thanh toán</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/account/order.blade.php ENDPATH**/ ?>