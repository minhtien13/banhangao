

<?php $__env->startSection('container'); ?>
    

  <?php echo $__env->make('banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="cuopons">
    <div class="container">
      <ul class="cuopons__list">
        <li class="cuopons__list-item">
          <img src="/template/images/sale.PNG" alt="" class="cuopons__list-image" />
          <div class="cuopons__list-content">
            <h3 class="cuopons__list-title">NHẬP MÃ: LAM15</h3>
            <p class="cuopons__list-desc">
              Mã giảm 15% cho đơn hàng tối thiểu 5tr
            </p>
            <div class="cuopons__list-bottom">
              <span class="btn cuopons__list-copy">Sao chép</span>
              <span href="" class="cuopons__list-info btn">Điều kiện</span>
            </div>
          </div>
        </li>
        <li class="cuopons__list-item">
          <img src="/template/images/sale.PNG" alt="" class="cuopons__list-image" />
          <div class="cuopons__list-content">
            <h3 class="cuopons__list-title">NHẬP MÃ: LAM15</h3>
            <p class="cuopons__list-desc">
              Mã giảm 15% cho đơn hàng tối thiểu 5tr
            </p>
            <div class="cuopons__list-bottom">
              <span class="btn cuopons__list-copy">Sao chép</span>
              <span href="" class="cuopons__list-info btn">Điều kiện</span>
            </div>
          </div>
        </li>
        <li class="cuopons__list-item">
          <img src="/template/images/vc.PNG" alt="" class="cuopons__list-image" />
          <div class="cuopons__list-content">
            <h3 class="cuopons__list-title">NHẬP MÃ: LAM15</h3>
            <p class="cuopons__list-desc">
              Mã giảm 15% cho đơn hàng tối thiểu 5tr
            </p>
            <div class="cuopons__list-bottom">
              <span class="btn cuopons__list-copy">Sao chép</span>
              <span href="" class="cuopons__list-info btn">Điều kiện</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </section>

  <?php echo $__env->make('porducts.loo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo App\helpers\helper::autoMenuList($menuHome); ?>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\shop-basic\resources\views/porducts/product.blade.php ENDPATH**/ ?>