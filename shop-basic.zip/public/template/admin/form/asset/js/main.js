setTimeout(() => {
  var main = document.querySelector(".overlay__loading");
  main.classList.add("os");
}, 1000 * 3);
